import { LayoutTemplate, MousePointerClick, ShoppingBag, Smartphone } from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import FadeIn from '../components/FadeIn';
import AnimatedText from '../components/AnimatedText';
import { ContactButton } from '../components/Buttons';
import { about } from '../data/content';

// Glossy 3D-style tiles built from icons, standing for what Sameer works on
function Glyph({ Icon, rotate }: { Icon: LucideIcon; rotate: number }) {
  return (
    <div className="glyph-tile flex aspect-square w-full items-center justify-center rounded-[28%]" style={{ transform: `rotate(${rotate}deg)` }}>
      <Icon className="h-[46%] w-[46%] text-white drop-shadow-[0_6px_10px_rgba(0,0,0,0.35)]" strokeWidth={1.6} />
    </div>
  );
}

const decor = [
  { Icon: ShoppingBag, rotate: -12, delay: 0.1, x: -80, className: 'top-[4%] left-[1%] w-[120px] sm:left-[2%] sm:w-[160px] md:left-[4%] md:w-[210px]' },
  { Icon: MousePointerClick, rotate: 10, delay: 0.25, x: -80, className: 'bottom-[8%] left-[3%] w-[100px] sm:left-[6%] sm:w-[140px] md:left-[10%] md:w-[180px]' },
  { Icon: LayoutTemplate, rotate: 12, delay: 0.15, x: 80, className: 'top-[4%] right-[1%] w-[120px] sm:right-[2%] sm:w-[160px] md:right-[4%] md:w-[210px]' },
  { Icon: Smartphone, rotate: -9, delay: 0.3, x: 80, className: 'bottom-[8%] right-[3%] w-[130px] sm:right-[6%] sm:w-[170px] md:right-[10%] md:w-[220px]' },
];

export default function AboutSection() {
  return (
    <section id="about" className="relative flex min-h-screen items-center justify-center px-5 py-20 sm:px-8 md:px-10">
      {decor.map(({ Icon, rotate, delay, x, className }, i) => (
        <div key={i} aria-hidden="true" className={`pointer-events-none absolute ${className}`}>
          <FadeIn delay={delay} x={x} y={0} duration={0.9}>
            <Glyph Icon={Icon} rotate={rotate} />
          </FadeIn>
        </div>
      ))}

      <div className="relative z-10 flex flex-col items-center gap-16 sm:gap-20 md:gap-24">
        <div className="flex flex-col items-center gap-10 sm:gap-14 md:gap-16">
          <FadeIn
            as="h2"
            delay={0}
            y={40}
            className="hero-heading text-center font-black uppercase leading-none tracking-tight"
            style={{ fontSize: 'clamp(3rem, 12vw, 160px)' }}
          >
            About me
          </FadeIn>
          <div className="flex max-w-[560px] flex-col gap-6">
            {about.map((paragraph, i) => (
              <AnimatedText
                key={i}
                text={paragraph}
                className="text-center font-medium leading-relaxed text-[#D7E2EA]"
                style={{ fontSize: 'clamp(1rem, 2vw, 1.35rem)' }}
              />
            ))}
          </div>
        </div>
        <ContactButton />
      </div>
    </section>
  );
}
