import type { MockVariant } from '../data/content';

type MockScreenProps = {
  variant: MockVariant;
  image?: string;
  alt?: string;
  label?: string;
  className?: string;
  eager?: boolean;
};

// Shared skeleton pieces
const line = 'block h-[5px] rounded-full bg-[#D7E2EA]/20';
const bold = 'block h-[10px] rounded-full bg-[#D7E2EA]/35';
const block = 'block rounded-lg bg-white/[0.07]';
const pill = 'contact-button block h-[14px] w-[34%] rounded-full';

function MockNav() {
  return (
    <div className="flex items-center justify-between gap-[6%]">
      <span className="block h-[7px] w-[14%] rounded-full bg-[#D7E2EA]/50" />
      <span className="flex flex-1 justify-center gap-[7%]">
        <span className={`${line} w-[12%]`} />
        <span className={`${line} w-[12%]`} />
        <span className={`${line} w-[12%]`} />
      </span>
      <span className="block h-[11px] w-[11px] rounded-full border-2 border-[#D7E2EA]/30" />
    </div>
  );
}

function MockBody({ variant }: { variant: MockVariant }) {
  switch (variant) {
    case 'product':
      return (
        <div className="grid flex-1 grid-cols-[1.1fr_1fr] gap-[6%]">
          <span className={`${block} bg-white/[0.1]`} />
          <span className="flex flex-col justify-center gap-[9%]">
            <span className={`${line} w-[30%]`} />
            <span className={`${bold} w-[90%]`} />
            <span className={`${line} w-[25%]`} />
            <span className="flex gap-2">
              <span className="block h-3 w-3 rounded-full bg-[#B600A8]/70 ring-2 ring-white/40 ring-offset-2 ring-offset-[#131417]" />
              <span className="block h-3 w-3 rounded-full bg-white/20" />
              <span className="block h-3 w-3 rounded-full bg-white/20" />
            </span>
            <span className="flex h-[20%] min-h-[16px] items-center justify-center rounded-md bg-[#D7E2EA] text-[0.5rem] font-semibold uppercase tracking-widest text-[#0C0C0C]">
              Add to cart
            </span>
          </span>
        </div>
      );
    case 'collection':
      return (
        <div className="flex flex-1 flex-col gap-[6%]">
          <span className={`${bold} w-[35%]`} />
          <div className="grid flex-1 grid-cols-3 gap-[4%]">
            {Array.from({ length: 6 }).map((_, i) => (
              <span key={i} className="flex flex-col gap-1.5">
                <span className={`${block} flex-1`} />
                <span className={`${line} w-[70%]`} />
              </span>
            ))}
          </div>
        </div>
      );
    case 'landing':
      return (
        <div className="flex flex-1 flex-col gap-[7%]">
          <div className="grid flex-[1.4] grid-cols-[1.3fr_1fr] items-center gap-[6%]">
            <span className="flex flex-col gap-2.5">
              <span className={`${bold} w-[95%]`} />
              <span className={`${bold} w-[65%]`} />
              <span className={`${line} w-[80%]`} />
              <span className={pill} />
            </span>
            <span className="block aspect-square rounded-full bg-gradient-to-br from-[#7621B0]/50 to-[#BE4C00]/40" />
          </div>
          <div className="grid flex-1 grid-cols-3 gap-[4%]">
            {Array.from({ length: 3 }).map((_, i) => (
              <span key={i} className="flex flex-col gap-2 rounded-lg border border-white/[0.06] p-[10%]">
                <span className={`${line} w-[50%] bg-[#D7E2EA]/35`} />
                <span className={`${line} w-[85%]`} />
              </span>
            ))}
          </div>
        </div>
      );
    case 'mobile':
      return (
        <div className="flex flex-1 items-end justify-center gap-[5%]">
          {Array.from({ length: 3 }).map((_, i) => (
            <span
              key={i}
              className={`flex aspect-[9/17] h-full flex-col gap-[6%] rounded-[14px] border border-white/10 bg-[#0C0C0C] p-[3%] ${i === 1 ? '' : 'scale-90 opacity-70'}`}
            >
              <span className={`${block} flex-[1.4] bg-white/[0.1]`} />
              <span className={`${line} w-[80%]`} />
              <span className={`${line} w-[45%]`} />
              <span className="block h-[12%] rounded-md bg-[#D7E2EA]/80" />
            </span>
          ))}
        </div>
      );
    case 'template':
      return (
        <div className="flex flex-1 flex-col gap-[6%]">
          <div className="grid flex-[1.6] grid-cols-[1fr_1.3fr] overflow-hidden rounded-lg">
            <span className="flex flex-col justify-center gap-2.5 bg-white/[0.04] p-[10%]">
              <span className={`${line} w-[35%]`} />
              <span className={`${bold} w-[90%]`} />
              <span className={`${bold} w-[60%]`} />
              <span className={pill} />
            </span>
            <span className="block bg-gradient-to-br from-[#2A1033] via-[#7621B0]/50 to-[#BE4C00]/40" />
          </div>
          <div className="grid flex-1 grid-cols-[2fr_1fr_1fr] gap-[3%]">
            <span className={block} />
            <span className={block} />
            <span className={block} />
          </div>
        </div>
      );
    case 'store':
    default:
      return (
        <div className="flex flex-1 flex-col gap-[6%]">
          <div className="grid flex-[1.3] grid-cols-2 items-center gap-[6%] rounded-lg bg-white/[0.04] p-[5%]">
            <span className="flex flex-col gap-2.5">
              <span className={`${line} w-[40%]`} />
              <span className={`${bold} w-[90%]`} />
              <span className={`${bold} w-[65%]`} />
              <span className={pill} />
            </span>
            <span className={`${block} h-full bg-white/[0.1]`} />
          </div>
          <div className="grid flex-1 grid-cols-4 gap-[3%]">
            {Array.from({ length: 4 }).map((_, i) => (
              <span key={i} className="flex flex-col gap-1.5">
                <span className={`${block} flex-1`} />
                <span className={`${line} w-[75%]`} />
                <span className={`${line} w-[35%]`} />
              </span>
            ))}
          </div>
        </div>
      );
  }
}

// Shows a real image when one is supplied, otherwise a clearly labelled placeholder
export default function MockScreen({ variant, image, alt = '', label = 'Add screenshot', className = '', eager = false }: MockScreenProps) {
  if (image) {
    return (
      <img
        src={image}
        alt={alt}
        loading={eager ? 'eager' : 'lazy'}
        decoding="async"
        className={`h-full w-full object-cover ${className}`}
      />
    );
  }

  return (
    <div role="img" aria-label={`Placeholder for ${alt || 'a project screenshot'}`} className={`relative overflow-hidden border border-white/[0.06] bg-[#131417] ${className}`}>
      <div aria-hidden="true" className="pointer-events-none absolute -right-12 -top-12 h-40 w-40 rounded-full bg-[#B600A8]/15 blur-3xl" />
      <div aria-hidden="true" className="absolute inset-0 flex flex-col gap-[6%] p-[6%]">
        <MockNav />
        <MockBody variant={variant} />
      </div>
      <span className="absolute bottom-3 left-3 inline-flex items-center gap-1.5 rounded-full bg-[#0C0C0C]/80 px-2.5 py-1 text-[0.65rem] font-medium uppercase tracking-wider text-[#D7E2EA]/80 backdrop-blur">
        <span className="h-1.5 w-1.5 rounded-full bg-[#BE4C00]" aria-hidden="true" />
        {label}
      </span>
    </div>
  );
}
