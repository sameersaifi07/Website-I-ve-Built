// ─────────────────────────────────────────────────────────────
// All editable site content lives in this file.
// Leave a value as '' to keep its labelled placeholder.
// Put image files in /public and reference them as '/my-image.webp',
// or paste a full https:// image URL.
// ─────────────────────────────────────────────────────────────

export type MockVariant = 'store' | 'product' | 'collection' | 'landing' | 'mobile' | 'template';

export const site = {
  name: 'Sameer',
  heroTagline: 'a shopify developer crafting attractive, easy-to-use online stores',
  // Portrait for the hero. A transparent PNG cut-out looks best, e.g. '/portrait.png'
  portrait: '',
  // Contact details. Nothing is invented: add your own.
  email: '', // e.g. 'hello@yourdomain.com'
  whatsapp: '', // full link, e.g. 'https://wa.me/<country code + number>'
  socials: [] as { label: string; href: string }[], // e.g. [{ label: 'LinkedIn', href: 'https://…' }]
};

export const about = [
  'I’m Sameer, a Shopify developer and website developer focused on creating attractive, easy-to-use online stores. I combine custom development with conversion rate optimisation (CRO) to help brands improve the shopping experience and turn more visitors into customers.',
  'From custom Shopify sections to complete website designs, I build with attention to detail, mobile usability, and performance. I also design and develop my own website templates, bringing a personal approach to every project.',
];

export const services = [
  {
    name: 'Shopify Development',
    description: 'Custom storefronts, theme customisation, and reusable sections tailored to each brand.',
  },
  {
    name: 'Website Design & Development',
    description: 'Responsive websites with clear layouts, intuitive navigation, and a consistent visual identity.',
  },
  {
    name: 'Conversion Rate Optimisation',
    description: 'Review and improvement of product pages, navigation, calls to action, and shopping journeys to reduce friction.',
  },
  {
    name: 'Custom Website Templates',
    description: 'Original, adaptable templates designed and developed with usability and visual consistency in mind.',
  },
];

// Scrolling preview strip. Add `image` to swap a placeholder for a real screenshot or GIF.
// The first half fills the top row, the rest fills the bottom row.
export const marqueeTiles: { image?: string; label: string; variant: MockVariant }[] = [
  { label: 'Storefront', variant: 'store' },
  { label: 'Product page', variant: 'product' },
  { label: 'Collection page', variant: 'collection' },
  { label: 'Landing page', variant: 'landing' },
  { label: 'Mobile layouts', variant: 'mobile' },
  { label: 'Website template', variant: 'template' },
  { label: 'Product page', variant: 'product' },
  { label: 'Storefront', variant: 'store' },
  { label: 'Mobile layouts', variant: 'mobile' },
  { label: 'Website template', variant: 'template' },
  { label: 'Landing page', variant: 'landing' },
  { label: 'Collection page', variant: 'collection' },
];

// Projects. Replace the bracketed names, add a live URL and three images per project.
export const projects: {
  name: string;
  category: string;
  url: string;
  images: [string, string, string];
  variants: [MockVariant, MockVariant, MockVariant];
}[] = [
  {
    name: '[Shopify store name]',
    category: 'Shopify Store',
    url: '',
    images: ['', '', ''],
    variants: ['product', 'mobile', 'store'],
  },
  {
    name: '[Website name]',
    category: 'Custom Website',
    url: '',
    images: ['', '', ''],
    variants: ['landing', 'collection', 'landing'],
  },
  {
    name: '[Template name]',
    category: 'Website Template · Designed & developed by me',
    url: '',
    images: ['', '', ''],
    variants: ['template', 'mobile', 'template'],
  },
];
