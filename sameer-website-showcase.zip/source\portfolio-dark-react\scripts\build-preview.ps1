# Builds a single-file browser preview (no Node.js needed) from the React sources.
# Usage (from the project folder):  powershell -ExecutionPolicy Bypass -File scripts\build-preview.ps1
$proj = Split-Path -Parent $PSScriptRoot
$order = @(
  "src\data\content.ts",
  "src\components\FadeIn.tsx",
  "src\components\Magnet.tsx",
  "src\components\AnimatedText.tsx",
  "src\components\Buttons.tsx",
  "src\components\MockScreen.tsx",
  "src\sections\HeroSection.tsx",
  "src\sections\MarqueeSection.tsx",
  "src\sections\AboutSection.tsx",
  "src\sections\ServicesSection.tsx",
  "src\sections\ProjectsSection.tsx",
  "src\sections\ContactSection.tsx",
  "src\App.tsx"
)
$sb = New-Object Text.StringBuilder
[void]$sb.AppendLine("const { useEffect, useRef, useState } = React;")
[void]$sb.AppendLine("const { motion, useScroll, useTransform, useReducedMotion, MotionConfig } = Motion;")
[void]$sb.AppendLine("const { ArrowUpRight, LayoutTemplate, MousePointerClick, ShoppingBag, Smartphone, Mail, MessageCircle } = LucideReact;")
foreach ($f in $order) {
  [void]$sb.AppendLine("// ---- $f")
  foreach ($ln in [IO.File]::ReadAllLines((Join-Path $proj $f))) {
    if ($ln -match '^\s*import\s') { continue }
    $ln = $ln -replace '^export default function ', 'function ' -replace '^export function ', 'function ' -replace '^export const ', 'const ' -replace '^export type ', 'type '
    [void]$sb.AppendLine($ln)
  }
}
[void]$sb.AppendLine("ReactDOM.createRoot(document.getElementById('root')).render(<App />);")
$src = $sb.ToString()
if ($src -match '</script') { throw "source contains </script" }

$css = [IO.File]::ReadAllText((Join-Path $proj "src\index.css")) -replace '@tailwind \w+;\s*', ''

$html = @"
<title>Sameer -- Shopify Developer</title>
<meta name="description" content="Sameer is a Shopify developer and website developer who combines custom Shopify development, responsive website design and conversion rate optimisation (CRO) to build better online stores.">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Kanit:wght@300;400;500;600;700;800;900&display=swap">
<script src="https://cdn.tailwindcss.com/3.4.1"></script>
<script>tailwind.config = { theme: { extend: { fontFamily: { sans: ['Kanit', 'sans-serif'] } } } };</script>
<style>
:root { color-scheme: dark; }
$css
#boot-error { max-width: 40rem; margin: 20vh auto; padding: 0 16px; font-family: Kanit, sans-serif; color: #D7E2EA; }
</style>
<div id="root"></div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/react/18.3.1/umd/react.production.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/react-dom/18.3.1/umd/react-dom.production.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/framer-motion@12.38.0/dist/framer-motion.js"></script>
<script src="https://cdn.jsdelivr.net/npm/lucide-react@0.344.0/dist/umd/lucide-react.min.js"></script>
<script src="https://unpkg.com/@babel/standalone@7.26.2/babel.min.js"></script>
<script type="text/plain" id="app-src">
$src
</script>
<script>
(function () {
  try {
    var code = Babel.transform(document.getElementById('app-src').textContent, {
      filename: 'app.tsx',
      presets: [['typescript', { isTSX: true, allExtensions: true }], ['react', { runtime: 'classic' }]]
    }).code;
    var s = document.createElement('script');
    s.textContent = code;
    document.body.appendChild(s);
  } catch (e) {
    document.getElementById('root').innerHTML = '<div id="boot-error"><p>The preview could not start: ' + String(e.message || e).replace(/</g, '&lt;') + '</p></div>';
  }
})();
</script>
"@
$out = Join-Path (Split-Path -Parent $proj) "sameer-3d-preview.html"
[IO.File]::WriteAllText($out, $html, (New-Object Text.UTF8Encoding $false))
"wrote $out ($((Get-Item $out).Length) bytes)"
