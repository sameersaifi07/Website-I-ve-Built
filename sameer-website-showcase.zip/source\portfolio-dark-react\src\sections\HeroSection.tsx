import FadeIn from '../components/FadeIn';
import Magnet from '../components/Magnet';
import { ContactButton } from '../components/Buttons';
import { site } from '../data/content';

const navLinks = [
  { label: 'About', href: '#about' },
  { label: 'Services', href: '#services' },
  { label: 'Projects', href: '#projects' },
  { label: 'Contact', href: '#contact' },
];

function HeroPortrait() {
  if (site.portrait) {
    return <img src={site.portrait} alt={`Portrait of ${site.name}`} className="h-auto w-full select-none" draggable={false} />;
  }
  // No stock photo stands in for you: this placeholder shows until a portrait is added in content.ts
  return (
    <div
      role="img"
      aria-label="Placeholder for your portrait"
      className="flex aspect-[4/5] w-full flex-col items-center justify-end gap-2 rounded-t-full border-2 border-b-0 border-dashed border-[#D7E2EA]/25 bg-[#0C0C0C]/30 pb-[18%] text-center backdrop-blur-[2px]"
    >
      <span className="text-sm font-medium uppercase tracking-widest text-[#D7E2EA]/70 sm:text-base">Your portrait</span>
      <span className="max-w-[70%] text-xs font-light text-[#D7E2EA]/45">Add a transparent PNG in content.ts</span>
    </div>
  );
}

export default function HeroSection() {
  return (
    <section className="relative flex h-screen min-h-[560px] flex-col" style={{ overflowX: 'clip' }}>
      <FadeIn as="nav" immediate delay={0} y={-20} className="relative z-20 px-6 pt-6 md:px-10 md:pt-8">
        <ul className="flex items-center justify-between gap-3">
          {navLinks.map((link) => (
            <li key={link.href}>
              <a
                href={link.href}
                className="text-sm font-medium uppercase tracking-wider text-[#D7E2EA] transition-opacity duration-200 hover:opacity-70 md:text-lg lg:text-[1.4rem]"
              >
                {link.label}
              </a>
            </li>
          ))}
        </ul>
      </FadeIn>

      <div className="overflow-hidden">
        <FadeIn
          as="h1"
          immediate
          delay={0.15}
          y={40}
          className="hero-heading mt-6 w-full whitespace-nowrap text-center text-[12vw] font-black uppercase leading-none tracking-tight sm:mt-4 sm:text-[12.8vw] md:-mt-5 md:text-[13.6vw] lg:text-[14.8vw]"
        >
          Hi, i&apos;m {site.name}
        </FadeIn>
      </div>

      <div className="absolute left-1/2 top-1/2 z-10 w-[280px] -translate-x-1/2 -translate-y-1/2 sm:bottom-0 sm:top-auto sm:w-[360px] sm:translate-y-0 md:w-[440px] lg:w-[520px]">
        <FadeIn immediate delay={0.6} y={30}>
          <Magnet padding={150} strength={3} activeTransition="transform 0.3s ease-out" inactiveTransition="transform 0.6s ease-in-out">
            <HeroPortrait />
          </Magnet>
        </FadeIn>
      </div>

      <div className="relative z-20 mt-auto flex items-end justify-between gap-6 px-6 pb-7 sm:pb-8 md:px-10 md:pb-10">
        <FadeIn
          as="p"
          immediate
          delay={0.35}
          y={20}
          className="max-w-[160px] font-light uppercase leading-snug tracking-wide text-[#D7E2EA] sm:max-w-[220px] md:max-w-[260px]"
          style={{ fontSize: 'clamp(0.75rem, 1.4vw, 1.5rem)' }}
        >
          {site.heroTagline}
        </FadeIn>
        <FadeIn immediate delay={0.5} y={20} className="shrink-0">
          <ContactButton />
        </FadeIn>
      </div>
    </section>
  );
}
