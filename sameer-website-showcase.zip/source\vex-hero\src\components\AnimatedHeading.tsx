import { useEffect, useState } from 'react';
import type { CSSProperties } from 'react';

type AnimatedHeadingProps = {
  text: string;
  className?: string;
  style?: CSSProperties;
  initialDelay?: number; // ms before the first character moves
  charDelay?: number; // ms between characters
  charDuration?: number; // ms per character transition
};

export default function AnimatedHeading({
  text,
  className = '',
  style,
  initialDelay = 200,
  charDelay = 30,
  charDuration = 500,
}: AnimatedHeadingProps) {
  const [animate, setAnimate] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setAnimate(true), initialDelay);
    return () => clearTimeout(timer);
  }, [initialDelay]);

  const lines = text.split('\n');

  return (
    <h1 className={className} style={style}>
      {lines.map((line, lineIndex) => {
        // Group characters into words so lines only wrap between words, never mid-word
        const words: { char: string; index: number }[][] = [[]];
        line.split('').forEach((char, index) => {
          words[words.length - 1].push({ char, index });
          if (char === ' ') words.push([]);
        });

        return (
          <span key={lineIndex} className="block">
            {words.map((word, wordIndex) => (
              <span key={wordIndex} className="inline-block whitespace-nowrap">
                {word.map(({ char, index: charIndex }) => {
                  const delay = lineIndex * line.length * charDelay + charIndex * charDelay;
                  return (
                    <span
                      key={charIndex}
                      className="inline-block"
                      style={{
                        opacity: animate ? 1 : 0,
                        transform: animate ? 'translateX(0)' : 'translateX(-18px)',
                        transition: `opacity ${charDuration}ms ease, transform ${charDuration}ms ease`,
                        transitionDelay: `${delay}ms`,
                      }}
                    >
                      {char === ' ' ? ' ' : char}
                    </span>
                  );
                })}
              </span>
            ))}
          </span>
        );
      })}
    </h1>
  );
}
