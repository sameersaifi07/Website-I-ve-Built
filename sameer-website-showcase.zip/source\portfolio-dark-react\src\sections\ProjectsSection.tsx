import { useRef } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import type { MotionValue } from 'framer-motion';
import FadeIn from '../components/FadeIn';
import MockScreen from '../components/MockScreen';
import { LiveProjectButton } from '../components/Buttons';
import { projects } from '../data/content';

type Project = (typeof projects)[number];

const imageRadius = 'rounded-[40px] sm:rounded-[50px] md:rounded-[60px]';
const topImageHeight = 'clamp(130px, 16vw, 230px)';
const bottomImageHeight = 'clamp(160px, 22vw, 340px)';

function ProjectCard({ project, index, total, progress }: { project: Project; index: number; total: number; progress: MotionValue<number> }) {
  const targetScale = 1 - (total - 1 - index) * 0.03;
  const scale = useTransform(progress, [index / total, 1], [1, targetScale]);
  const [img1, img2, img3] = project.images;
  const [v1, v2, v3] = project.variants;

  return (
    <div className="sticky top-24 flex h-[85vh] items-start justify-center md:top-32">
      <motion.article
        style={{ scale, top: `${index * 28}px` }}
        className="relative w-full origin-top rounded-[40px] border-2 border-[#D7E2EA] bg-[#0C0C0C] p-4 sm:rounded-[50px] sm:p-6 md:rounded-[60px] md:p-8"
      >
        <div className="mb-5 flex flex-wrap items-end justify-between gap-4 px-2 sm:mb-6 sm:px-3">
          <div className="flex min-w-0 items-end gap-4 sm:gap-6">
            <span className="font-black leading-none text-[#D7E2EA] tabular-nums" style={{ fontSize: 'clamp(2.75rem, 8vw, 110px)' }}>
              {String(index + 1).padStart(2, '0')}
            </span>
            <div className="flex min-w-0 flex-col gap-1 pb-1 sm:pb-2">
              <span className="text-xs uppercase tracking-widest text-[#D7E2EA]/60 sm:text-sm">{project.category}</span>
              <h3 className="font-medium uppercase text-[#D7E2EA]" style={{ fontSize: 'clamp(1.1rem, 2.6vw, 2.2rem)' }}>
                {project.name}
              </h3>
            </div>
          </div>
          <LiveProjectButton url={project.url} />
        </div>

        <div className="flex gap-3">
          <div className="flex w-[40%] flex-col gap-3">
            <div style={{ height: topImageHeight }}>
              <MockScreen variant={v1} image={img1} alt={`${project.name} screenshot 1`} className={imageRadius} />
            </div>
            <div style={{ height: bottomImageHeight }}>
              <MockScreen variant={v2} image={img2} alt={`${project.name} screenshot 2`} className={imageRadius} />
            </div>
          </div>
          <div className="w-[60%]" style={{ height: `calc(${topImageHeight} + ${bottomImageHeight} + 0.75rem)` }}>
            <MockScreen variant={v3} image={img3} alt={`${project.name} main screenshot`} className={imageRadius} />
          </div>
        </div>
      </motion.article>
    </div>
  );
}

export default function ProjectsSection() {
  const listRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: listRef, offset: ['start start', 'end end'] });

  return (
    <section
      id="projects"
      className="relative z-10 -mt-10 rounded-t-[40px] bg-[#0C0C0C] px-5 pb-20 pt-20 sm:-mt-12 sm:rounded-t-[50px] sm:px-8 sm:pt-24 md:-mt-14 md:rounded-t-[60px] md:px-10 md:pt-32"
    >
      <FadeIn
        as="h2"
        y={40}
        className="hero-heading mb-12 text-center font-black uppercase leading-none tracking-tight sm:mb-16"
        style={{ fontSize: 'clamp(3rem, 12vw, 160px)' }}
      >
        Project
      </FadeIn>

      <div ref={listRef} className="mx-auto max-w-6xl">
        {projects.map((project, i) => (
          <ProjectCard key={i} project={project} index={i} total={projects.length} progress={scrollYProgress} />
        ))}
      </div>
    </section>
  );
}
