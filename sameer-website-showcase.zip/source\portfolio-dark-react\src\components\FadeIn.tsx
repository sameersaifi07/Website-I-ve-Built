import { motion } from 'framer-motion';
import type { CSSProperties, ReactNode } from 'react';

type FadeInProps = {
  children?: ReactNode;
  as?: string;
  delay?: number;
  duration?: number;
  x?: number;
  y?: number;
  className?: string;
  style?: CSSProperties;
  // Animate on load instead of on scroll. Use for above-the-fold content, and for content inside
  // an overflow-hidden mask, where the hidden start position never registers as in view.
  immediate?: boolean;
};

// motion.create() is called once per tag so components keep a stable identity between renders
const motionTags = new Map<string, any>();
function getMotionTag(tag: string) {
  if (!motionTags.has(tag)) motionTags.set(tag, motion.create(tag as any));
  return motionTags.get(tag);
}

export default function FadeIn({ children, as = 'div', delay = 0, duration = 0.7, x = 0, y = 30, className, style, immediate = false }: FadeInProps) {
  const Tag = getMotionTag(as);
  const shown = { opacity: 1, x: 0, y: 0 };
  return (
    <Tag
      className={className}
      style={style}
      initial={{ opacity: 0, x, y }}
      {...(immediate ? { animate: shown } : { whileInView: shown, viewport: { once: true, margin: '50px', amount: 0 } })}
      transition={{ duration, delay, ease: [0.25, 0.1, 0.25, 1] }}
    >
      {children}
    </Tag>
  );
}
