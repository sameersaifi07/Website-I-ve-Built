# Sameer – Shopify Developer portfolio

React + TypeScript + Tailwind CSS + Framer Motion + Lucide React, built with Vite.

## Run it

You need [Node.js](https://nodejs.org) 18 or newer.

```bash
npm install
npm run dev
```

Build for hosting (outputs to `dist/`):

```bash
npm run build
```

## Edit your content

Everything you'll want to change is in **`src/data/content.ts`**:

| What | Field |
| --- | --- |
| Hero portrait (transparent PNG works best) | `site.portrait` |
| Email, WhatsApp, social links | `site.email`, `site.whatsapp`, `site.socials` |
| About text | `about` |
| Services | `services` |
| Scrolling preview strip | `marqueeTiles[].image` |
| Projects: name, type, live link, 3 images each | `projects` |

Put image files in a `public/` folder and reference them like `'/store-home.webp'`,
or paste a full `https://` image URL. Any empty value keeps its labelled placeholder,
and a project without a URL shows "Link coming soon" instead of a dead button.

## Sections

`HeroSection` → `MarqueeSection` → `AboutSection` → `ServicesSection` → `ProjectsSection` → `ContactSection` (with footer), all in `src/sections/`.
Reusable pieces (`FadeIn`, `Magnet`, `AnimatedText`, `ContactButton`, `LiveProjectButton`, `MockScreen`) are in `src/components/`.
