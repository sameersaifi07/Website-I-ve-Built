import { useEffect, useRef, useState } from 'react';
import { useReducedMotion } from 'framer-motion';
import MockScreen from '../components/MockScreen';
import { marqueeTiles } from '../data/content';

type Tile = (typeof marqueeTiles)[number];

function MarqueeRow({ tiles, x }: { tiles: Tile[]; x: number }) {
  const tripled = [...tiles, ...tiles, ...tiles];
  return (
    // Starts one set to the left so the row never shows an empty edge while it moves
    <div className="flex w-max gap-3" style={{ transform: `translateX(calc(-33.333% + ${x}px))`, willChange: 'transform' }}>
      {tripled.map((tile, i) => (
        <MockScreen
          key={i}
          variant={tile.variant}
          image={tile.image}
          alt={tile.label}
          label={tile.label}
          className="h-[180px] w-[280px] shrink-0 rounded-2xl sm:h-[270px] sm:w-[420px]"
        />
      ))}
    </div>
  );
}

export default function MarqueeSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const [offset, setOffset] = useState(0);
  const reduceMotion = useReducedMotion();

  useEffect(() => {
    if (reduceMotion) return;
    let frame = 0;
    const update = () => {
      frame = 0;
      const el = sectionRef.current;
      if (!el) return;
      const sectionTop = el.getBoundingClientRect().top + window.scrollY;
      setOffset((window.scrollY - sectionTop + window.innerHeight) * 0.3);
    };
    const onScroll = () => {
      if (!frame) frame = requestAnimationFrame(update);
    };
    update();
    window.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('resize', onScroll);
    return () => {
      window.removeEventListener('scroll', onScroll);
      window.removeEventListener('resize', onScroll);
      cancelAnimationFrame(frame);
    };
  }, [reduceMotion]);

  const half = Math.ceil(marqueeTiles.length / 2);
  return (
    <section ref={sectionRef} aria-label="Work previews" className="flex flex-col gap-3 overflow-hidden bg-[#0C0C0C] pb-10 pt-24 sm:pt-32 md:pt-40">
      <MarqueeRow tiles={marqueeTiles.slice(0, half)} x={offset - 200} />
      <MarqueeRow tiles={marqueeTiles.slice(half)} x={-(offset - 200)} />
    </section>
  );
}
