import { useEffect, useState } from 'react';
import type { ReactNode } from 'react';

type FadeInProps = {
  children: ReactNode;
  delay?: number; // ms before the fade starts
  duration?: number; // ms
  className?: string;
};

export default function FadeIn({ children, delay = 0, duration = 1000, className = '' }: FadeInProps) {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setVisible(true), delay);
    return () => clearTimeout(timer);
  }, [delay]);

  return (
    <div
      className={`transition-opacity ${visible ? 'opacity-100' : 'opacity-0'} ${className}`}
      style={{ transitionDuration: `${duration}ms` }}
    >
      {children}
    </div>
  );
}
