import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  // Relative asset paths, so the build also works from a GitHub Pages subfolder
  base: './',
  // Keep paths as written; avoids resolving to a redirected Windows folder the dev server can't read
  resolve: { preserveSymlinks: true },
});
