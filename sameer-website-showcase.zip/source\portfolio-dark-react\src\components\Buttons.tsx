import { ArrowUpRight } from 'lucide-react';

type ContactButtonProps = { href?: string; label?: string };

export function ContactButton({ href = '#contact', label = 'Contact Me' }: ContactButtonProps) {
  return (
    <a
      href={href}
      className="contact-button inline-flex whitespace-nowrap items-center justify-center rounded-full px-8 py-3 sm:px-10 sm:py-3.5 md:px-12 md:py-4 text-xs sm:text-sm md:text-base font-medium uppercase tracking-widest text-white transition-transform duration-200 hover:-translate-y-0.5 hover:brightness-110"
    >
      {label}
    </a>
  );
}

export function LiveProjectButton({ url }: { url: string }) {
  const base =
    'inline-flex items-center justify-center gap-2 rounded-full border-2 border-[#D7E2EA] px-8 py-3 sm:px-10 sm:py-3.5 text-sm sm:text-base font-medium uppercase tracking-widest text-[#D7E2EA] transition-colors duration-200';

  // No URL yet: say so instead of linking nowhere
  if (!url) {
    return (
      <span className={`${base} cursor-not-allowed border-dashed opacity-50`} aria-disabled="true">
        Link coming soon
      </span>
    );
  }
  return (
    <a href={url} target="_blank" rel="noopener noreferrer" className={`${base} hover:bg-[#D7E2EA]/10`}>
      Live Project <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
    </a>
  );
}
