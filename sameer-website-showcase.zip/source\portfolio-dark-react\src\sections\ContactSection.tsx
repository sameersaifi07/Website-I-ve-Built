import { Mail, MessageCircle } from 'lucide-react';
import FadeIn from '../components/FadeIn';
import { ContactButton } from '../components/Buttons';
import { site } from '../data/content';

function Channel({ label, value, href, Icon }: { label: string; value: string; href: string; Icon: typeof Mail }) {
  return (
    <li className="flex items-center justify-between gap-4 border-t border-[#D7E2EA]/15 py-4">
      <span className="flex items-center gap-3 text-sm uppercase tracking-widest text-[#D7E2EA]/60">
        <Icon className="h-4 w-4" aria-hidden="true" /> {label}
      </span>
      {href ? (
        <a href={href} target={href.startsWith('http') ? '_blank' : undefined} rel="noopener noreferrer" className="break-all text-right text-[#D7E2EA] underline decoration-[#D7E2EA]/30 underline-offset-4 transition-colors hover:decoration-[#D7E2EA]">
          {value}
        </a>
      ) : (
        <span className="rounded-full border border-dashed border-[#D7E2EA]/30 px-3 py-1 text-xs uppercase tracking-wider text-[#D7E2EA]/50">Not added yet</span>
      )}
    </li>
  );
}

export default function ContactSection() {
  const year = new Date().getFullYear();
  return (
    <section id="contact" className="relative z-10 bg-[#0C0C0C] px-5 pb-10 pt-16 sm:px-8 md:px-10 md:pt-24">
      <div className="mx-auto flex max-w-3xl flex-col items-center gap-10 text-center">
        <FadeIn as="h2" y={40} className="hero-heading font-black uppercase leading-none tracking-tight" style={{ fontSize: 'clamp(2.6rem, 9vw, 120px)' }}>
          Let&apos;s talk
        </FadeIn>
        <FadeIn as="p" delay={0.1} y={20} className="max-w-xl font-light leading-relaxed text-[#D7E2EA]" style={{ fontSize: 'clamp(1rem, 1.8vw, 1.3rem)' }}>
          Need a Shopify store, a custom website, or a better shopping experience? Tell me about your project.
        </FadeIn>
        <FadeIn delay={0.2} y={20} className="w-full max-w-lg">
          <ul className="border-b border-[#D7E2EA]/15 text-left">
            <Channel label="Email" value={site.email} href={site.email ? `mailto:${site.email}` : ''} Icon={Mail} />
            <Channel label="WhatsApp" value="Message me" href={site.whatsapp} Icon={MessageCircle} />
          </ul>
        </FadeIn>
        {site.email && (
          <FadeIn delay={0.3} y={20}>
            <ContactButton href={`mailto:${site.email}`} label="Email Me" />
          </FadeIn>
        )}
      </div>

      <footer className="mx-auto mt-24 flex max-w-6xl flex-wrap items-center justify-between gap-4 border-t border-[#D7E2EA]/15 pt-6 text-sm text-[#D7E2EA]/60">
        <span>© {year} {site.name}</span>
        <nav aria-label="Footer" className="flex flex-wrap gap-x-6 gap-y-2 uppercase tracking-wider">
          <a href="#about" className="transition-opacity hover:opacity-70">About</a>
          <a href="#services" className="transition-opacity hover:opacity-70">Services</a>
          <a href="#projects" className="transition-opacity hover:opacity-70">Projects</a>
          {site.socials.map((s) => (
            <a key={s.href} href={s.href} target="_blank" rel="noopener noreferrer" className="transition-opacity hover:opacity-70">
              {s.label}
            </a>
          ))}
        </nav>
        <span className="contact-button inline-flex items-center rounded-full px-4 py-2 text-xs font-medium uppercase tracking-widest text-white">
          Created by&nbsp;<strong className="font-bold">Sameer Saifi</strong>
        </span>
      </footer>
    </section>
  );
}
