import AnimatedHeading from './components/AnimatedHeading';
import FadeIn from './components/FadeIn';

const VIDEO_URL =
  'https://d8j0ntlcm91z4.cloudfront.net/user_38xzZboKViGWJOttwIXH07lWA1P/hf_20260403_050628_c4e32401-fab4-4a27-b7a8-6e9291cd5959.mp4';

const navLinks = ['Story', 'Investing', 'Building', 'Advisory'];

export default function App() {
  return (
    <section className="relative flex h-screen flex-col overflow-hidden bg-black text-white">
      {/* Raw background video: no overlay, no dimming */}
      <video
        className="absolute inset-0 h-full w-full object-cover"
        src={VIDEO_URL}
        autoPlay
        loop
        muted
        playsInline
      />

      {/* Navbar */}
      <div className="relative z-10 px-6 pt-6 md:px-12 lg:px-16">
        <nav className="liquid-glass flex items-center justify-between rounded-xl px-4 py-2">
          <span className="text-2xl font-semibold tracking-tight">VEX</span>
          <ul className="hidden items-center gap-8 md:flex">
            {navLinks.map((link) => (
              <li key={link}>
                <a href={`#${link.toLowerCase()}`} className="text-sm transition-colors hover:text-gray-300">
                  {link}
                </a>
              </li>
            ))}
          </ul>
          <button type="button" className="rounded-lg bg-white px-6 py-2 text-sm font-medium text-black transition-colors hover:bg-gray-100">
            Start a Chat
          </button>
        </nav>
      </div>

      {/* Hero content, pushed to the bottom */}
      <div className="relative z-10 flex flex-1 flex-col justify-end px-6 pb-12 md:px-12 lg:grid lg:grid-cols-2 lg:items-end lg:px-16 lg:pb-16">
        <div>
          <AnimatedHeading
            text={'Shaping tomorrow\nwith vision and action.'}
            className="mb-4 text-4xl font-normal md:text-5xl lg:text-6xl xl:text-7xl"
            style={{ letterSpacing: '-0.04em' }}
          />

          <FadeIn delay={800} duration={1000}>
            <p className="mb-5 text-base text-gray-300 md:text-lg">
              We back visionaries and craft ventures that define what comes next.
            </p>
          </FadeIn>

          <FadeIn delay={1200} duration={1000}>
            <div className="flex flex-wrap gap-4">
              <button type="button" className="rounded-lg bg-white px-8 py-3 font-medium text-black">
                Start a Chat
              </button>
              <button
                type="button"
                className="liquid-glass rounded-lg border border-white/20 px-8 py-3 font-medium text-white transition-colors hover:bg-white hover:text-black"
              >
                Explore Now
              </button>
            </div>
          </FadeIn>
        </div>

        <div className="mt-8 flex items-end justify-start lg:mt-0 lg:justify-end">
          <FadeIn delay={1400} duration={1000} className="flex flex-col items-start gap-3 lg:items-end">
            <div className="liquid-glass rounded-xl border border-white/20 px-6 py-3">
              <p className="text-lg font-light md:text-xl lg:text-2xl">Investing. Building. Advisory.</p>
            </div>
            <p className="liquid-glass inline-flex items-center gap-2 rounded-full border border-white/20 px-4 py-1.5 text-xs tracking-wide text-gray-300">
              <span className="h-1.5 w-1.5 rounded-full bg-white shadow-[0_0_8px_#fff]" aria-hidden="true" />
              Created by <strong className="font-semibold text-white">Sameer Saifi</strong>
            </p>
          </FadeIn>
        </div>
      </div>
    </section>
  );
}
